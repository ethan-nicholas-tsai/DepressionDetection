# -*- coding: utf-8 -*-
__all__ = ["BaseTimeSeriesForest"]

from ._ensemble import BaseTimeSeriesForest
