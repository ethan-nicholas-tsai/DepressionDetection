# -*- coding: utf-8 -*-
__all__ = [
    "HIVECOTEV1",
]

from sktime.classification.hybrid._hivecote_v1 import HIVECOTEV1
