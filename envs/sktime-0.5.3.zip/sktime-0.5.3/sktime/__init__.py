# -*- coding: utf-8 -*-
__version__ = "0.5.3"

__all__ = ["show_versions"]

from sktime.utils._maint._show_versions import show_versions
