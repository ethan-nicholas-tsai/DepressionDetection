.. _user_guide_transformations:

Time Series Transformations
===========================

.. note::

    The user guide is under development. We have created a basic
    structure and are looking for contributions to develop the user guide
    further. For more details, please go to issue `#361 <https://github
    .com/alan-turing-institute/sktime/issues/361>`_ on GitHub.


.. contents:: :local:

Tabular-to-tabular transformations
----------------------------------

Series-to-primitives transformations
------------------------------------

Series-to-series transformations
--------------------------------

Panel-to-tabular transformations
--------------------------------

Panel-to-panel transformations
------------------------------
