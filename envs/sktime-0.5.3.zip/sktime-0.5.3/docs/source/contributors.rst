.. _contributors:

.. mdinclude:: ../../CONTRIBUTORS.md
