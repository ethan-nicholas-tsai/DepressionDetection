.. _exceptions_ref:

sktime.exceptions: Exceptions
=============================

The :mod:`sktime.exceptions` module contains classes for exceptions and warnings.

.. autosummary::
    :template: class.rst

    sktime.exceptions
