.. _developer_guide_classification:

Time Series Classification
==========================

.. note::

    The developer guide is under development. We have created a basic
    structure and are looking for contributions to develop the guide
    further. For more details, please go to issue `#464 <https://github
    .com/alan-turing-institute/sktime/issues/464>`_ on GitHub.
