.. _contributing:

.. mdinclude:: ../../CONTRIBUTING.md
