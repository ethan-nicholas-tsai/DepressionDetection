Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog <https://keepachangelog.com/en/1.0.0/>`_ and we adhere to `Semantic Versioning <https://semver.org/spec/v2.0.0.html>`_.

We keep track of changes in this file since v0.4.0.


[Unreleased]
------------
Added
~~~~~
-

Changed
~~~~~~~
-

Removed
~~~~~~~
-

Fixed
~~~~~
-

Deprecated
~~~~~~~~~~
-


[0.4.0] - 2019-04-xx
--------------------

Added
~~~~~
- Added changelog.

Changed
~~~~~~~
-

Removed
~~~~~~~
-

Fixed
~~~~~
-

Deprecated
~~~~~~~~~~
-
